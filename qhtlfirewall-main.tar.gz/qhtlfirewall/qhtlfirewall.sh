#!/bin/bash
#
###############################################################################
# Copyright (C) 2025 Daniel Nowakowski
#
# https://qhtlf.danpol.co.uk
###############################################################################
#
# chkconfig: 2345 15 80
# description: QhtLink Firewall
#
### BEGIN INIT INFO
# Provides:          qhtlfirewall
# Required-Start:    $network
# Required-Stop:     $network
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# X-Start-Before:    $syslog
# Short-Description: QhtLink Firewall (qhtlfirewall)
# Description:       QhtLink Firewall (qhtlfirewall) init script
### END INIT INFO
#

[ -f /usr/sbin/qhtlfirewall ] || exit 0

# Source function library.
if [ -f /etc/init.d/functions ]; then
	. /etc/init.d/functions
fi

DAEMON=/usr/sbin/qhtlfirewall
LOCKFILE=/var/lock/subsys/qhtlfirewall

if [ -f /etc/SuSE-release ]; then
	. /etc/rc.status
	rc_reset
fi

case "$1" in
  start)
	echo -n "Starting qhtlfirewall:"
	$DAEMON --initup
	if [ -f /etc/SuSE-release ]; then
		rc_status -v
	elif [ -f /etc/debian_version ] || [ -f /etc/lsb-release ] || [ -f /etc/gentoo-release ]; then
		echo " Done"
	else
		success
		echo
	fi
	echo
	if [ -e /var/lock/subsys/ ]; then
		touch $LOCKFILE
	fi
	;;
  stop)
	echo "WARNING: This script should ONLY be used by the init process. To restart qhtlfirewall use the CLI command 'qhtlfirewall -r'"
	echo
	echo -n "Stopping qhtlfirewall:"
	$DAEMON --initdown
	$DAEMON --stop > /dev/null 2>&1
	if [ -f /etc/SuSE-release ]; then
		rc_status -v
	elif [ -f /etc/debian_version ] || [ -f /etc/lsb-release ] || [ -f /etc/gentoo-release ]; then
		echo " Done"
	else
		success
		echo
	fi
	echo
	if [ -e /var/lock/subsys/ ]; then
		rm -f $LOCKFILE
	fi
	;;
  status)
        echo -n "Status of qhtlfirewall:"
	$DAEMON --status
	echo
        ;;
  restart|force-reload|reload)
	$0 stop
	$0 start
	;;
  *)
	echo "Usage: /etc/init.d/qhtlfirewall start|stop|restart|force-reload|status"
	exit 1
esac

exit 0
