#!/bin/sh

echo "This plugin is installed by installing qhtlfirewall from the root shell"

exit 0;
