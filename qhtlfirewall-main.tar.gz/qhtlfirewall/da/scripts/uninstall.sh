#!/bin/sh

echo "This plugin is uninstalled by uninstalling qhtlfirewall from the root shell"

exit 0;
