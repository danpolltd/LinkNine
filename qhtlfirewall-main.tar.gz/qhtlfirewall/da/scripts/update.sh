#!/bin/sh

echo "This plugin is updated by updating qhtlfirewall from the root shell"

exit 0;
