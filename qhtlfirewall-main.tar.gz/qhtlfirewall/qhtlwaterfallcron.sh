SHELL=/bin/sh
0 0 * * * root /usr/sbin/qhtlfirewall --qhtlwaterfall restart > /dev/null 2>&1
