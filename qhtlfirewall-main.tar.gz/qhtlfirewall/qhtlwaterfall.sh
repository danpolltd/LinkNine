#!/bin/bash
#
###############################################################################
# Copyright (C) 2025 Daniel Nowakowski
#
# https://qhtlf.danpol.co.uk
###############################################################################
#
# chkconfig: 2345 20 75
# description: Login Failure Daemon
#
### BEGIN INIT INFO
# Provides:          qhtlwaterfall
# Required-Start:    $network $syslog
# Required-Stop:     $network $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: qhtlfirewall Login Failure Daemon (qhtlwaterfall)
# Description:       qhtlfirewall Login Failure Daemon (qhtlwaterfall) init script
### END INIT INFO
#

[ -f /usr/sbin/qhtlwaterfall ] || exit 0

# Source function library.
if [ -f /etc/init.d/functions ]; then
	. /etc/init.d/functions
fi

RETVAL=0
PID=/var/run/qhtlwaterfall.pid
DAEMON=/usr/sbin/qhtlwaterfall
PIDOF=pidof

if [ -f /etc/SuSE-release ]; then
	. /etc/rc.status
	rc_reset
fi

# See how we were called.
case "$1" in
  start)
	echo -n "Starting qhtlwaterfall:"
    ulimit -n 4096
	$DAEMON
	if [ -f /etc/SuSE-release ]; then
		rc_status -v
	elif [ -f /etc/debian_version ] || [ -f /etc/lsb-release ] || [ -f /etc/gentoo-release ]; then
		echo " Done"
	else
		success
		echo
	fi
	;;
  stop)
	echo -n "Stopping qhtlwaterfall:"
	if [ -f /etc/SuSE-release ]; then
		killproc qhtlwaterfall
		rc_status -v
	elif [ -f /etc/debian_version ] || [ -f /etc/lsb-release ] || [ -f /etc/gentoo-release ]; then
		qhtlwaterfall=`cat /var/run/qhtlwaterfall.pid 2>/dev/null`
		if [ -n "${qhtlwaterfall}" ] && [ -e /proc/"${qhtlwaterfall}" ]; then
			kill "$qhtlwaterfall";
		fi
		echo " Done"
	else
		killproc qhtlwaterfall
		success
		echo
	fi
	;;
  status)
        echo -n "Status of qhtlwaterfall:"
	if [ -f /etc/SuSE-release ]; then
	        checkproc qhtlwaterfall
	        rc_status -v
		RETVAL=$?
	elif [ -f /etc/debian_version ] || [ -f /etc/lsb-release ] || [ -f /etc/gentoo-release ]; then
		qhtlwaterfall=`cat /var/run/qhtlwaterfall.pid 2>/dev/null`
		if [ -n "${qhtlwaterfall}" ] && [ -e /proc/"${qhtlwaterfall}" ]; then
			echo " Running"
		else
			echo " Stopped"
			RETVAL=3
		fi
	else
		status qhtlwaterfall
		RETVAL=$?
		echo
	fi
        ;;
  restart|force-reload)
	$0 stop
	$0 start
	;;
  *)
	echo "Usage: /etc/init.d/qhtlwaterfall start|stop|restart|force-reload|status"
	exit 1
esac

exit $RETVAL
